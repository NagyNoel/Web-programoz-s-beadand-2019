<?php
$host='localhost';
//interneten
$felhasznalonev='noelbeadando';
$adatbazisnev='noelbeadando';
//localhoston
//$adatbazisnev='beadando';
//$felhasznalonev='beadando';
$jelszo='noel1234';

?>