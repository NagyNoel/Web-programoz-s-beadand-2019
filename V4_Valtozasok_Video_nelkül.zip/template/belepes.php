<table class="Menu" style="color:black;width:400px;text-align:left;height:180px;">
<form action="?oldal=belep" method="post">
<tr><td colspan="2"><h2>Belépés<h2><td></tr>
<tr><td>Felhasználónév:</td><td><input type="text" name="felhasznaloNevText" required></td></tr>
<tr><td>Jelszó:</td><td><input type="password" name="jelszoText" required></td></tr>
<tr><td colspan=2><br><input type="submit" value="Belépés" name="belepesButton"></td></tr>
</form>
</table>
<br>
<table class="Menu" style="border-top: 1px solid black; color:black;width:400px;text-align:left;height:270px;">
<form action="?oldal=regisztral" method="post">
<tr><td colspan="2"><h2>Regisztráció<h2><td></tr>
<tr><td>Vezetéknév:</td><td><input type="text" name="vezetekNevText" required></td></tr>
<tr><td>Keresztnév:</td><td><input type="text" name="keresztNevText" required></td></tr>
<tr><td>Felhasználónév:</td><td><input type="text" name="felhasznaloNevText" required></td></tr>
<tr><td>Jelszó:</td><td><input type="password" name="jelszo1Text" required></td></tr>
<tr><td>Jelszó újra:</td><td><input type="password" name="jelszo2Text" required></td></tr>
<tr><td colspan=2><br><input type="submit" value="Regisztráció" name="regisztracioButton"></td></tr>
</form>
</table>