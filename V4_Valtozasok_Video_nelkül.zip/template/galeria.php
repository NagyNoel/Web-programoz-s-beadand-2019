<?php
$uzenet="";
if(isset($_FILES['Kepfajl']))
{
	if(!move_uploaded_file($_FILES['Kepfajl']['tmp_name'],$galeria.$_FILES['Kepfajl']['name']))
	$uzenet="Sikertelen feltöltés";
}
?>

<table class="Menu" style="color:black;text-align:center;">
<tr><td colspan="4" height=30px style="text-align:right;">

<?=$uzenet;?>

<form method="post" action="./?oldal=galeria" enctype="multipart/form-data">
<input type="file" name="Kepfajl">
<input type="submit" value="Feltöltés">
</form>
</td></tr>
<tr>
<?php
$files=scandir($galeria);
$images=array();
$Oszlop=0;
foreach($files as $file)
{
	if($file=='.'||$file=='..') continue;
	echo '<td><a href="'.$galeria.$file.'"><img src="'.$galeria.$file.'" width="220" ></a></td>';
	$Oszlop++;
	if($Oszlop==4)
	{echo '</tr><tr><td height=27px></td></tr><tr>'; $Oszlop=0;}
}
?>
</tr>
</table>