<!DOCTYPE html>

<?php
session_start();

if(file_exists("./logical/{$keres['fajl']}.php"))
	{
		include("./logical/{$keres['fajl']}.php");		
	}
?>

<html>
<head>
<link rel="stylesheet" href="./stilus/stilus.css">
<meta charset="utf-8">
<title><?php echo $keres['cim']?> - <?php echo $ablakcim['cim']?></title>
</head>

<body>
<header>
<table class="Menu" style="color:#0066CC;height:40px;">
<tr>
<?php
if(isset($_SESSION['login']))
{
?>
<td><a style="color:#0066CC;" href="./?oldal=kilep">Kilépés<a></td>

<?php
	
}
else 
{
	
?>
<td><a style="color:#0066CC;" href="./?oldal=belepes">Belépés<a></td>
<?php
}
?>
<td><a style="color:#0066CC;" href="./?oldal=kapcsolatok">Kapcsolatok<a></td>
<td><img src="./kepek/otkarika.png" style="height:40px"><td>
<td><img src="./kepek/mkb.png" style="height:40px"><td>
<td><img src="./kepek/heraklesz.jpg" style="height:40px"><td>
<td><img src="./kepek/sport_xxi.png" style="height:40px"><td>
<td><img src="./kepek/adidas.png" style="height:40px"><td>
<td><img src="./kepek/burgerKing.png" style="height:40px"><td>
<td><img src="./kepek/EWF.jpg" style="height:40px"><td>
<td><img src="./kepek/iwf.jpg" style="height:40px"><td>
<td><img src="./kepek/CEWF.png" style="height:40px"><td>
</tr>
</table>
<table class="Menu">
<tr>
<td colspan="7"><a href="http://mssz.hu/">
<img src="./kepek/boritokep.jpg"></a>
</td>
</tr>
<tr style="background:#0066CC;height:40px;">
<td><a href="./?oldal=fooldal">HOME</a></td>
<td><a href="./?oldal=galeria">GALÉRIA</a></td>
<td><a href="./?oldal=versenyek">VERSENYEK</a></td>
<td><a href="./?oldal=statisztika">STATISZTIKA</a></td>
<td><a href="http://mssz.hu/heraklesz/">HÉRAKLÉSZ</a></td>
<td><a href="http://utanpotlas.mssz.hu/">UTÁNPÓTLÁS</a></td>
<td><a href="http://masters.mssz.hu/">MASTERS</a></td>
</tr>

<tr>
<td colspan="7" style="text-align:right;">
<form action="http://www.google.co.hu/search" method="get">
<input type="text" maxlength="100" name="q" size="20" value="" />
<input type="submit" name="gomb" value="Google keresés" />
<input type="hidden" name="domains" value="http://www.nemhivatalosmssz.nhely.hu" />
</form>
</td>
</tr>

</table>
</header>

<?php
include("./template/{$keres['fajl']}.php");
?>

</body>
</html>