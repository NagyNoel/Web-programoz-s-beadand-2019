<?php
$uzenet='';
include('./konfig/adatb.php');
	try
	{
		$dbh=new PDO("mysql:host={$host};dbname={$adatbazisnev}",$felhasznalonev,$jelszo,array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
		$dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
		
		$query=$dbh->prepare("SELECT * FROM uzenetek");
		$query->execute();
		
		$rows = $query->fetchAll();
	}
	catch (PDOException $e)
	{
			$uzenet="Sikertelen üzenetlekérdezés";
	}

?>

<table class="Menu" style="color:black;width:800px;text-align:left;height:180px;">
<tr><td colspan="3"><h1><?=$uzenet?></h1></td></tr>
<tr><td colspan="3"><h2>Üzenetek<h2></td></tr>
<tr height=20px><td></td><td></td><td></td></tr>
<tr><td  width=170px><B>Név</B></td><td width=220px><B>E-mail</B></td><td><B>Üzenet</B></td></tr>
<tr height=10px><td></td><td></td></tr>
<?php
	foreach ($rows as $row)
	{
		echo '<tr height=5px><td></td><td></td></tr>';
		echo '<tr><td valign="top">'.$row['nev'].'</td><td valign="top">'.$row['email'].'</td><td valign="top">'.$row['uzenet'].'</td></tr>';
	}
?>
</table>