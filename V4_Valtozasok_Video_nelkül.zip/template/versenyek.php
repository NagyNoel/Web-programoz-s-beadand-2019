<table class="Menu" style="color:black;text-align:left;">
<tr><td colspan=4><h2 style="text-align:center;">2019. évi versenynaptár</h2></td></tr>
<tr style="font-weight:bold;"><td>Dátum</td><td>Verseny neve</td><td>Helyszín</td><td>Kiemelt</td></tr>


     <tr><td>2019.02.09</td><td> 		Területi minõsítõ verseny</td><td>		Szombathely	 		</td><td> 	N</td>
</tr><tr><td>2019.02.16</td><td> 		Baczakó Péter Emlékverseny</td><td>		BKV Elõre			</td><td>   K</td>
</tr><tr><td>2019.02.16</td><td> 		Dóró Antal Emlékverseny</td><td>		Téglás	 			</td><td>	N</td>
</tr><tr><td>2019.02.22</td><td> 		Baczakó P Ter.min.verseny</td><td>		BKV Elõre			</td><td>   N</td>
</tr><tr><td>2019.02.23</td><td> 		Budapest Bajnokság</td><td>				Bp, TSE	 		 	</td><td>	N</td>
</tr><tr><td>2019.02.23</td><td> 		Csongrád megyei bajnokság</td><td>		Szeged	 			</td><td>	N</td>
</tr><tr><td>2019.02.23</td><td> 		Ördögh István Emlékverseny</td><td>		Tiszaújváros		</td><td> 	N</td> 	 
</tr><tr><td>2019.03.06</td><td> 		K.Városi Bajnokság</td><td>				Kecskemét	 	 	</td><td>	N</td>
</tr><tr><td>2019.03.08-03.15</td><td> 	Ifjúsági VB 2019</td><td>				Las Vegas (USA)	 	</td><td>   K</td>	 	 
</tr><tr><td>2019.03.08-03.10</td><td> 	International Open</td><td>				Las Vegas /USA/	 	</td><td>   K</td>	 	 
</tr><tr><td>2019.03.09</td><td> 		Területi Minõsítõ verseny</td><td>		Tatabánya	 		</td><td>	N</td>
</tr><tr><td>2019.03.16</td><td> 		Savaria Kupa</td><td>					Szombathely	 		</td><td>   K</td> 	
</tr><tr><td>2019.03.16</td><td> 		Területi minõsítõ verseny</td><td>		Szolnok	 		 	</td><td>	N</td>
</tr><tr><td>2019.03.22-04.22</td><td> 	Isk.Ter.min.v.</td><td>					Iregszemcse	 	 	</td><td>	N</td>
</tr><tr><td>2019.03.31</td><td> 		Területi minõsítõ verseny</td><td>		Szerencs	 		</td><td>	N</td>	 
</tr><tr><td>2019.04.06-04.15</td><td> 	Felnõtt EB 2019</td><td>				Batumi (GEO)	 	</td><td>   K</td>		 	 
</tr><tr><td>2019.04.06</td><td> 		MEFOB 2019</td><td>						Bp, MAFC	 		</td><td>	N</td>
</tr><tr><td>2019.04.06</td><td> 		Területi minõsítõ verseny</td><td>		Pécs	 			</td><td>	N</td> 
</tr><tr><td>2019.04.13</td><td> 		Masters OB 2019</td><td>				BKV Elõre	 		</td><td>	N</td>
</tr><tr><td>2019.04.27-04.28</td><td> 	Iskolás OB 2019</td><td>				BKV Elõre	 		</td><td>	N</td> 
</tr><tr><td>2019.04.27</td><td> 		Területi Minõsítõ Verseny</td><td>		Téglás	 			</td><td> 	N</td> 
</tr><tr><td>2019.05.11</td><td> 		CSB selejtezõ (kelet)</td><td>			Téglás	 	 		</td><td>	N</td>
</tr><tr><td>2019.05.11</td><td> 		CSB selejtezõ (nyugat)</td><td>			Zalaegerszeg		</td><td> 	N</td> 	 
</tr><tr><td>2019.05.11</td><td> 		Csinger Gyula Emlékverseny</td><td>		Bp, MAFC			</td><td> 	N</td> 	 
</tr><tr><td>2019.05.12</td><td> 		Göcsej Kupa</td><td>					Zalaegerszeg		</td><td>   K</td>	 
</tr><tr><td>2019.05.25</td><td> 		Tini OB (kelet)</td><td>				Abaújszántó	 		</td><td>	N</td> 	 
</tr><tr><td>2019.05.25</td><td> 		Tini OB (nyugat)</td><td>				Kisbér	 			</td><td>	N</td> 
</tr><tr><td>2019.06.01</td><td> 		Juhász Sándor Emlékverseny</td><td>		Biharnagybajom		</td><td>   K</td>	 		 	 
</tr><tr><td>2019.06.01-06.08</td><td> 	Junior VB 2019</td><td>					Suva (FIJ)	  		</td><td> 	K</td>		 	 
</tr><tr><td>2019.06.08-06.15</td><td> 	Masters EB 2019</td><td>				Rovaniemi (FIN)	 	</td><td> 	K</td>	 		 	 
</tr><tr><td>2019.06.22</td><td> 		Ireg Kupa</td><td>						Iregszemcse	 		</td><td> 	N</td>
</tr><tr><td>2019.07.06</td><td> 		Kisbér Kupa</td><td>					Kisbér				</td><td>   K</td>
</tr><tr><td>2019.07.07-07.15</td><td> 	Junior és U23 EB 2019</td><td>			Chisinau (MDA)	 	</td><td>  	K</td>		 	 
</tr><tr><td>2019.07.20</td><td> 		Narancs Kupa</td><td>					Téglás	 			</td><td>	N</td>
</tr><tr><td>2019.07.26-08.04</td><td> 	European Masters Games 2019</td><td>	Turin (ITA)			</td><td>   K</td> 		 	 
</tr><tr><td>2019.08.03</td><td> 		Messzi István Emlékverseny</td><td>		Kecskemét			</td><td>   K</td>		 	 
</tr><tr><td>2019.08.16-08.24</td><td> 	Masters VB 2019</td><td>				Montreal (CAN)		</td><td>   K</td>		 	 
</tr><tr><td>2019.08.24</td><td> 		Területi Minõsítõ Verseny</td><td>		Biharnagybajom	 	</td><td>	N</td>	 	 
</tr><tr><td>2019.09.05-09.14</td><td> 	U15 és U17 EB 2019</td><td>				Constanca (ROU)	  	</td><td> 	K</td>		 	 
</tr><tr><td>2019.09.14</td><td> 		Pécs Város Bajnoksága</td><td>			Pécs	 	 		</td><td>	N</td>
</tr><tr><td>2019.09.14</td><td> 		Téglás Kupa</td><td>					Téglás	 	 		</td><td> 	N</td>
</tr><tr><td>2019.09.16-09.25</td><td> 	Felnõtt VB 2019</td><td>				Pattaya (THA)		</td><td>   K</td> 		 	 
</tr><tr><td>2019.09.24</td><td> 		Suzuki Kupa</td><td>					Ózd	 				</td><td>  	K</td>
</tr><tr><td>2019.10.05-10.06</td><td> 	U15-U17 OB</td><td>						Kisbér	 			</td><td>  	K</td> 
</tr><tr><td>2019.10.20</td><td> 		Tini OB (kelet)</td><td>				???	 				</td><td> 	N</td>
</tr><tr><td>2019.10.20</td><td> 		Tini OB (nyugat)</td><td>				???	 	 			</td><td>	N</td>
</tr><tr><td>2019.10.26</td><td> 		Területi Minõsítõ Verseny</td><td>		Biharnagybajom		</td><td> 	N</td>	 	 
</tr><tr><td>2019.11.02-11.03</td><td> 	Junior OB 2019</td><td>					Szerencs			</td><td>   K</td> 	 
</tr><tr><td>2019.11.09</td><td> 		Mûegyetem Kupa</td><td>					Bp, MAFC			</td><td>	K</td> 
</tr><tr><td>2019.11.16</td><td> 		Kiss Róbert Emlékverseny</td><td>		Zalaegerszeg	 	</td><td> 	N</td>		 	 
</tr><tr><td>2019.11.23-11.24</td><td> 	Felnõtt OB 2019</td><td>				Oroszlány (OVSK)	</td><td>	K</td>		 	 
</tr><tr><td>2019.11.23</td><td> 		Kõszegi György Emlékverseny</td><td>	Tiszaújváros		</td><td>	N</td>		 	 
</tr><tr><td>2019.12.08</td><td> 		CSB Döntõ</td><td>						???	   				</td><td>	K</td>
</tr><tr><td>2019.12.15</td><td> 		Advent Kupa</td><td>					Bp, REAC			</td><td>	N</td> 
</tr><tr><td>2019.12.15</td><td> 		HAJDÚ Zrt Kupa</td><td>					Téglás				</td><td>	K</td>
</tr>

</table>