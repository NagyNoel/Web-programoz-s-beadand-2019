<table class="Menu" style="color:black;width:600px;text-align:left;height:180px;">
<form action="?oldal=kuldes" method="post">
<tr><td><h2>Üzenet küldés<h2></td><td class="Uzenet" style="text-align:right"><a href="./?oldal=uzenetek">Üzenetek</a></td></tr>
<tr height=10px><td></td><td></td></tr>
<tr><td>Név:</td><td><input type="text" name="nev" required></td></tr>
<tr height=10px><td></td><td></td></tr>
<tr><td>E-mail:</td><td><input type="email" name="email" required></td></tr>
<tr height=10px><td></td><td></td></tr>
<tr><td style="vertical-align:top">Üzenet:</td><td><textarea rows=20 cols=100 name="uzenetText" required></textarea></td></tr>
<tr><td colspan=2 style="text-align:right"><br><input type="submit" value="Küldés" name="KuldesButton"></td></tr>
</form>
</table>