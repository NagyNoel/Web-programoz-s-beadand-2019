<table class="Menu" style="color:black;text-align:left;">
<tr>
<td height=40px></td>
<td style="vertical-align:bottom;color:#0066CC">Cikkek:</td>
</tr>
<tr>
	<td>
		<iframe src="https://www.youtube.com/embed/mKLExOEN6tA?autoplay=1" style="display:inline-block;" seamless width=750px height=420px></iframe>
	</td>
	<td>
		<table>
		<tr>
			<td><a href="#Mefob">
			<img src="./kepek/Mefob.JPG" width=170px>
			</a>
			</td>
		</tr>
		<tr>
			<td><a href="#FelnottOB">
			<img src="./kepek/felnottOB.jpg" width=170px>
			</a>
			</td>
		</tr>
		<tr>
			<td><a href="#elsomef">
			<img src="./kepek/elsomefKep.jpg" width=170px>
			</a>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>

<div class="Menu" style="color:black;text-align:left;">
<article id="Mefob">
<h1>2019-es MEFOB</h1>
<p>
2019. április 6.-án rendezték meg a 2018/2019. évi súlyemelő MEFOB versenyt. A rendező a Budapesti Műszaki Egyetem volt. Nagy Noel tavalyi aranyérmes súlyemelőnk az idei évben is képviselte egyetemünket. A versenyt követően kérdeztük az elért eredménnyel kapcsolatban.
</p><p>
Járdi Ádám: A verseny előtti beszélgetésünk alkalmával kitűztél magad elé egy célt. Hogyan értékeled a második MEFOB-od?
</p><p>
Nagy Noel: Rendkívül nehéz felkészülést tudhatok magam mögött. Minden téren sok akadállyal küzdöttem, de még így is kimagasló, magamhoz képest is remek eredményt emeltem a hétvégén. Számokban ez annyit tesz, hogy a 111 kilogrammos szakítás volt a teteje. A 115-öt is megpróbáltam, amit még a mai napig nem tudom, hogy eshetett le, hiszen gyönyörű gyakorlat volt, valószínűleg egyszerűen meglepődtem a súly alatt „milyen könnyű”. Sajnos ez volt az egyik legfontosabb gyakorlat, de mivel az edzéseken alig voltam 100 kilogramm fölött, így a 111 is egy nagy előrelépés.
</p><p>
J.Á: A folytatásban következtett a további fogásnem. Itt milyen eredménnyel zártál?
</p><p>
N.N: Ezt követően 145 kilogrammot löktem a fejem fölé a második fogásnemben! Új egyéni csúcs, 3 tárcsa a rúdon, illetve ez is jóval az edzésen nyújtott eredményem felett volt, sőt a tavaly ugyanitt emelt súlynál 20 kilóval több! Sajnos ez még csak az adott időben jelentett előnyt, mivel nagy ellenfelem, szintén kilökte ezt a súlyt ezért 150 kilógrammra kellett mennem a győzelemért, amit könnyedén fel is vettem, viszont a lökésre kijött a „régi rossz mozgás”. Végezetül az ellenfél kilökte a 150-et, ezáltal ismét hátrányba kerültem, de további fogások híján ő vitte el az aranyérmet, illetve az abszolút kupát is.
</p><p>
J.Á: Ha a verseny előtt azt mondják az abszolút kupa második helye a tiéd elégedett lettél volna?
</p><p>
N.N: Úgy gondolom nincs miért szégyenkezni, mivel az egész MEFOB 2. legerősebb versenyzője voltam és nagyon kevesen múlt, hogy nem nyertem és vittem el mindent. Ezt az eredményt feldolgoztam és kicsit vicces de apukám nyomdokaiba léphetek. Ő 10 MEFOB aranyéremmel rendelkezik, mely mellett lóg egy ezüst is. Ezt idén kipipáltam, innentől jöhet a további 9 arany.
</p>
</article>

<article id="FelnottOB">
<h1>Felnőtt OB</h1>
<p>
Felnőtt Magyar Súlyemelő Bajnokságot rendeztek a hétvégén Szombathelyen a Haladás Sportkomplexumban. Idén egy sikeres MEFOB aranyérem után, itt a következő alkalom, mikor Nagy Noel, a Neumann János Egyetem mérnökinformatikus hallgatója ismét a dobogó legfelső fokára állhatott. Ez alkalommal a Felnőtt korcsoportban is.
</p><p>
A MEFOB után, hogy zajlott a felkészülés a Felnőtt OB-ra, voltak e nehézségek, nehéz összeegyeztetni az egyetemi életet a sporttal?
</p><p>
A sport mindig belefér a zsúfolt mindennapjaimba. Az egyetemen úgy állítottam össze az órarendem, hogy mindig legyen időm az edzésekre. Néha a zárthelyi dolgozatok miatt természetesen kimarad egy-két edzés, de igyekszem minél több időt fordítani rá, így nálam inkább a pihenés, kikapcsolódás marad el.
</p><p>
Nehézségek mindig vannak ebben az évben pedig igazán sok megpróbáltatáson kellett átmennem, átmennünk családommal. Ezeket csak pár szóban megemlítve: Év elején apukám, aki egyben az edzőtársam is lesérült, ami kicsit visszafogta a lendületem, viszont nem törte meg, azóta is mellettem áll és támogat mindenben. Utána pár hónapja bekerültem a kórházba, mivel 1-es típusú cukorbeteg lettem. Ekkor fogásonként 40-50 kg-ot estem vissza, amit szerencsére, azóta visszaküzdöttem.  Illetve ezek után anyukám is bekerül a kórházba 45 évesen és körülbelül 2 hete temettük el.
</p><p>
Mindezen felül erős maradtam és dolgoztam, tanultam és edzettem, aminek végül meglett az eredménye 2. Felnőtt Magyar bajnoki aranyérmem.
</p><p>
Nézzük is akkor ezt a versenyt, mi volt a legemlékezetesebb?
</p><p>
Nagyon sok inger éri a versenyzőket egy versenyen főleg, ha az egy ilyen rangos, hiszen a felnőtt korcsoportban mindenki elindulhat, aki 15 éves elmúlt és megemeli a nevezési szintet. Elsőként egy nagyon hosszú utazás volt. Mikor megérkeztünk a versenyhelyszínre, ami egy hatalmas stadionban volt, hirtelen meg se találtuk a súlyemelőket. Kis tekergés után, követve a tárcsák hangjait odaértünk a női első versenyre. Fél óra volt még mérésig, amit beszélgetéssel töltöttünk, majd 68,7 kg-al mérlegeltem a 69 kg-os súlycsoportba.
</p><p>
Mennyit emeltél? Hogy voltak a kezdősúlyok.
</p><p>
Életem legmagasabb kezdősúlyán kezdtem szakításban, 110 kg-on. Eddig a legmagasabb is „csak” 102 volt. Már ez egy nagydolog volt, de a melegítőhelységben annyira könnyűnek láttuk a súlyokat, hogy mindenképpen itt akartunk kezdeni. Nem is álltunk itt meg, második fogásra, az első sikeres teljesítése után, 115 kg-ot kértünk ki. Sajnos elsőre túl sok erőt adtam bele, így mögöttem leesett, viszont 3. fogásra pont megfelelő volt minden, így 115 kg lett a vége a szakításnak. Ellenfelem is idáig jutott.
</p><p>
Következett a lökés. Már többször löktem 140 kg felett is, azonban ahogy a mondás tartja nálunk „lökj annyit, amennyi kell”, néztük az ellenfelet, aki jóval alacsonyabb súlyon kezdett, 126 kg-on. Emiatt nekem 127-re kellett mennem. Amint kilöktem nyerő pozícióban voltam. Itt következett a macskaegér harc. 130-ra tetette az ellenfél, én 131-re mindketten kilöktük! Gondolkoztak hova tegyék az utolsót, a 3. fogást. Végül 137 mellett döntöttek, amit azonban nem tudott kilökni, így itt meg is volt az arany. Mi azonban nem álltunk itt meg, tehát kimentem a 3. fogásra 137-re, viszont nekem 3 fehér jelezés lett, ami a jó gyakorlatot jelenti. Ezért végül 115-137-et emeltem, amibe még érzés szerint fért volna pár kiló.
</p><p>
Azt a pár kilót ebben az évben lesz alkalmad bizonyítani még?
</p><p>
Természetesen! Még egy CSB nevű Csapat Bajnokság lesz rendezve Oroszlányban. Ott megemelhetem, állíthatok fel új csúcsokat, azonban ott a csapat érdekeit fogjuk nézni, ott nincs egyéni törekvés, a biztosabb fogásokra megyünk, azonban edzésen addig fel fogunk szaladni párszor.
</p><p>
Jövőre pedig, hogy tervezed a versenyeket?
</p><p>
Körülbelül ugyanezeken a versenyeken fogok indulni. Országos bajnokságok MEFOB, és pár kiemelt illetve kisebb területi minősítő, amihez kedvünk lesz. Most a CSB után neki kezdünk egy nagy alapozásnak, mint minden évben, hogy az erő meglegyen, utána pedig csak a technikát kell hozzá alakítani versenyek előtt.
</p><p>
Ha pedig ugyanennyi drukkolóm, szurkolóm lesz, mint idén, akik ott állnak mellettem és ezúton is köszönöm mindenkinek, aki segített bármi formában, akkor ugyanilyen szép csillogó érmeket szeretnék nekik hozni jövőre is.
</p>

<video controls autoplay preload="auto" loop muted>
<source src="./videok/PecsDiakOlimpia2017.mp4" type="video/mp4">
</video>

</article>

<article id="elsomef">
<h1>2018-as Mefob</h1>
<p>
Április 7-én, szombaton került megrendezésre az 51. súlyemelő MEFOB, az egyetemesek országos bajnoksága. Idén Egyetemünkről Nagy Noel, elsőéves mérnökinformatikus hallgatónk képviseltette magát a 69 kg-os súlycsoportban.
</p><p>
Hogyan sikerült a verseny?
</p><p>
Nem is tudom, hol kezdjem. Ez volt az első MEFOB versenyem. Ezelőtt még nem szerepeltem hasonló kihívásom, igaz sok helyen indultam már és küzdöttem a dobogóért, de ez most teljesen más volt. Más a nevezés, mások az ellenfelek, sok új fantasztikus embert ismertem meg, egyedül a súlycsoport volt, ami nem változott.
</p><p>
Pénteken már kicsit visszafogtam az étkezéseket és beültem egy 15 perces körre a szaunába is, hogy a súlyom meglegyen a mérésre, ne legyen több. A versenyen mindkét fogásnemben, így összetettben is új egyéni rekordokat sikerült emelnem.
</p><p>
Térjünk is rá a súlyokra. Mekkora súlyokat sikerült felemelned?
</p><p>
Szakításban, az első fogásom után már elég nagy előnyre tettem szert az ellenfelekkel szemben; ez 100 kg volt, ez azonban nem volt akadálya annak, hogy tovább haladjak, és utolsó fogásra elérjem a 112 kg-os szakítást.
</p><p>
Lökésben egy kisebb súlyon kezdtem, azonban a szakításban összehozott előny miatt már ezzel a fogással feljutottam a dobogó tetejére. Ez után viszont hátra volt még két fogásom. A második fogásom már 11kg-mal meghaladta az elsőt, de ez még nem volt egyéni csúcs. Utolsó fogásra kikértük a 141 kg-ot. Nagyon könnyen felvettem, visszatekintve úgy érzem, el is bíztam kicsit magam miatta, mivel a gyakorlat vége 1-2 centivel elcsúszott, így sajnos leesett a nagy súly.
</p><p>
Ezek szerint könnyedén nyertél?
</p><p>
Nem, egyáltalán nem! Elsősorban, be kellett állítani a súlyom, ami nem könnyű. Továbbá a 69-77 kg-os súlycsoportban vannak a legtöbben mindig. Ezen a versenyen főleg, hisz az egyetemisták, mind szinte ezekben a súlycsoportokban tornyosulnak. 77 kg-ban 17 ember is küzdött a dobogó fokaiért.
</p><p>
Nagyon szép eredmények születtek, az ellenfelek előtt le a kalappal. A felsőoktatási tanulmányok mellett nem sok idő jut az edzésekre, ezt tapasztalatból mondom. Szóval, aki ide eljutott és megmutatta magát, már az egy kis győzelem minden versenyzőnek.
</p><p>
Három aranyéremmel tértél haza aznap, hogy sikerült ennyit elhoznod?
</p><p>
A három aranyéremből csak egyet nyertem aznap; a legszebbet – a MEFOB aranyat. Nagyon szép domborműves érmet hoztak össze a szervezők. A másik kettőt a Csapat bajnokság selejtezőjén és a döntőben szereztem a kecskeméti csapat tagjaként.
</p><p>
Azonban volt egy 4. érem is aznap a családomban! Azon a napon szervezték a Masters Magyar Bajnokságot is, szintén Budapesten. Nehezen, de meggyőztem édesapámat, hogy induljon el ő is. Sikeres gyakorlatokkal zárva a napot, az ő nyakába is akasztottak egy aranyérmet.
</p>
</article>
</div>