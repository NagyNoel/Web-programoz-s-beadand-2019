<?php
$uzenet='';
include('./konfig/adatb.php');
if(!isset($_POST['nev'])&&!isset($_POST['email'])&&!isset($_POST['uzenetText']))
{
$uzenet="Kötelezöen megadandó adatok hiányosnak!";
}
else
{
	try
	{
		$dbh=new PDO("mysql:host={$host};dbname={$adatbazisnev}",$felhasznalonev,$jelszo,array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
		$dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
		
		$query=$dbh->prepare("INSERT INTO uzenetek VALUES(:nev, :email, :uzenet);");
		$query->execute(array(':nev' => $_POST['nev'], ':email' => $_POST['email'], ':uzenet' => $_POST['uzenetText']));
			$uzenet="Üzenet sikeresen rögzítve";
	}
	catch (PDOException $e)
	{
			$uzenet="Sikertelen üzenetrögzítés";
	}
}
?>

<table class="Menu" style="color:black;width:600px;text-align:left;height:180px;">
<tr><td colspan="2"><h1><?=$uzenet?></h1></td></tr>


<tr><td colspan="2"><h2>Üzenet<h2></td></tr>
<tr height=10px><td></td><td></td></tr>
<tr><td>Név:</td><td><?=$_POST['nev']?></td></tr>
<tr height=10px><td></td><td></td></tr>
<tr><td>E-mail:</td><td><?=$_POST['email']?></td></tr>
<tr height=10px><td></td><td></td></tr>
<tr><td style="vertical-align:top">Üzenet:</td><td><?=$_POST['uzenetText']?></td></tr>

</table>