<table class="Menu" style="color:black;text-align:left;width:600px;margin-top:30px">
<tr>
<td><img src="./kepek/404.jpg" width="200" style="width:200"></td>
<td><h1>Hiba!<br>Az oldal nem található!</h1></td>
</tr>
</table>