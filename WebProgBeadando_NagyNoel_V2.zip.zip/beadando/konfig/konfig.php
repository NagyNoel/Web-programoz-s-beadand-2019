<?php
$ablakcim = array(
'cim' => 'Magyar Súlyemelő Szövetség'
);

$oldalak = array(
'fooldal' => array('fajl' => 'fooldal', 'cim' => 'Főoldal'),
'belepes' => array('fajl' => 'belepes', 'cim' => 'Belépés'),
'kapcsolatok' => array('fajl' => 'kapcsolatok', 'cim' => 'Kapcsolatok'),
'statisztika' => array('fajl' => 'statisztika', 'cim' => 'Statisztika'),
'versenyek' => array('fajl' => 'versenyek', 'cim' => 'Versenyek'),
);


$hiba_oldal = array('fajl' => '404', 'cim' => 'Hiba');
?>