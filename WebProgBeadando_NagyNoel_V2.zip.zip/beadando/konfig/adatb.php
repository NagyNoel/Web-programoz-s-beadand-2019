<?php
$host='localhost';
$felhasznalonev='beadando';
$jelszo='noel1234';
$adatbazisnev='beadando'
?>