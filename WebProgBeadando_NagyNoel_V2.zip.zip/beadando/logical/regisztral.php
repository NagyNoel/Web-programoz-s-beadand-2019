<?php
include('./konfig/adatb.php');
if(isset $_POST['vezetekNevText'] && isset $_POST['keresztNevText'] && isset $_POST['felhasznaloNevText'] && isset $_POST['jelszo1Text'] && isset $_POST['jelszo2Text'])
{
	try
	{
		$dbh=new PDO('mysql:host={$host};dbname={$adatbazisnev}',$felhasznalonev,$jelszo,array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
		$dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
	}
	catch
	{}
}
?>