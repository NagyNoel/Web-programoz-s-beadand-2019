<?php
include('./konfig/adatb.php');
if(isset($_POST['vezetekNevText']) && isset($_POST['keresztNevText']) && isset($_POST['felhasznaloNevText']) && isset($_POST['jelszo1Text']) && isset($_POST['jelszo2Text']))
{
	if($_POST['jelszo1Text']!=$_POST['jelszo2Text'])
	{
		$uzenet="Jelszók nem egyeznek";
		die();
	}
	try
	{
		$dbh=new PDO("mysql:host={$host};dbname={$adatbazisnev}",$felhasznalonev,$jelszo,array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
		$dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
		
		$query=$dbh->prepare("SELECT username FROM felhasznalok WHERE username = :fnev");
		$query->execute(array(':fnev' => $_POST['felhasznaloNevText']));
		if ($row = $query->fetch())
		{
			$uzenet="A felhasználónév már létezik";
		}
		else
		{
			$query = $dbh->prepare("INSERT INTO felhasznalok(username, password, nev) VALUES(:fnev, :jelszo, :tnev)");
			$query->execute(array(':fnev' => $_POST['felhasznaloNevText'], ':jelszo' => $_POST['jelszo1Text'], ':tnev' => $_POST['vezetekNevText'] . ' ' . $_POST['keresztNevText']));
			$uzenet="Sikeres regisztráció";
		}
	}
	catch (PDOException $e)
	{
		$uzenet="Hiba a regisztrációban";
	}
}
?>