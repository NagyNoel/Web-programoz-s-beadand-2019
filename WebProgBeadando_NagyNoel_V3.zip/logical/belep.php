<?php
include('./konfig/adatb.php');
if(isset($_POST['felhasznaloNevText']) && isset($_POST['jelszoText']))
{
	try
	{
		$dbh=new PDO("mysql:host={$host};dbname={$adatbazisnev}",$felhasznalonev,$jelszo,array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
		$dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
		
		$query=$dbh->prepare("SELECT username, nev FROM felhasznalok WHERE username = :fnev AND password= :jelszo");
		$query->execute(array(':fnev' => $_POST['felhasznaloNevText'], ':jelszo' => $_POST['jelszoText']));
		if ($row = $query->fetch())
		{			
			$uzenet="Bejelentkezett: {$row['nev']} ({$row['username']})";
			$_SESSION['login']=$_POST['felhasznaloNevText'];
		}
		else
		{			
			$uzenet="Sikertelen belépés";
		}
	}
	catch (PDOException $e)
	{
		$uzenet="Sikertelen belépés";
	}
}
?>