<?php
unset($_SESSION['login']);
?>