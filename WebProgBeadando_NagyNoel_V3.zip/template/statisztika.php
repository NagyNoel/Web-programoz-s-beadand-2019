<table class="Menu" style="color:black;text-align:left;width:700px;">
<tr><td colspan=2><h3>2018-as eredmények</h3></td></tr>
<tr><td colspan=2><h4>Szakosztályi pontverseny</h4>
<p>Szakosztályonként a legjobb nyolc versenyző által - korosztályos OB-n, EB-n, VB-n - elért legmagasabb pontszám összesítve (az összetett eredmény sinclair és nőknél az 1,35-ös szorzóval szorozva)</p></td></tr>
<tr><td style="width:500px">
<ol>
<li>Kecskeméti TE</li>
<li>BKV Előre SC</li>
<li>Haladás VSE</li>
<li>Oroszlány Városi Súlyemelő és Erőemelő Club</li>
<li>Pécsi Súlyemelő Egyesület</li>
<li>FIRMITAS Súlyemelő Club (TSSE)</li>
</ol>
</td>
<td style="text-align:left">
2663.99<br>
2373.85<br>
2267.67<br>
2251.07<br>
2073.90<br>
2053.78
</td>
</tr>
<tr>
<td colspan="2" class="Uzenet"><a href="http://versenyeredm.hu/statisztika/szakosztalyi-pontverseny.html">Teljes lista</a></td></tr>
<tr><td colspan=2><h3>Abszolút csapatbajnokság</h3></td></tr>
<tr><td colspan=2><p>Öt fős csapatok versenyznek selejtezőben és a döntőben. (Az összetett eredmények sinclair szorzóval, nőknél az 1,35-ös szorzóval is szorozva. Két fő utánpótlás korú versenyző bónusz pontot kap.)</p></td></tr>
<tr><td colspan=2 class="Uzenet"><a href="#">Selejtező</a><br><br><a href="#">Döntő</a></td></tr>
<tr><td colspan=2><h3>Országos bajnokságok pontversenye -> Összesített pontverseny</h3></td></tr>
<tr><td colspan=2><p>Felnőtt és korosztályos OB-n az elért helyezések alapján számolt sorrend (a győztesek 7, a 2-6. helyezettek 5-4-3-2-1 pontot kapnak)</p></td></tr>
<tr><td colspan=2 class="Uzenet"><a href="http://versenyeredm.hu/statisztika/pontverseny.php">Teljes lista</a></td></tr>
<tr><td colspan=2><h3>Versenyen indulók létszáma</h3></td></tr>
<tr><td colspan=2><p>Összesítés a január 1. óta legalább egy versenyen elindult versenyzők számáról egyesületi és korcsoportonkénti bontásban. Az év közben átigazolt versenyzők az átadó egyesületnél szerepelnek.</p></td></tr>
<tr><td colspan=2 class="Uzenet"><a href="http://versenyeredm.hu/statisztika/szakosztalyok_induloi.php">Mostani állapot</a><br><br><a href="#">Féléves összesítő</a></td></tr>
</table>