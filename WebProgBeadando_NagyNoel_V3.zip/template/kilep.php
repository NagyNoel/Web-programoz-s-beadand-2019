<table class="Menu" style="color:black;text-align:left;width:600px;margin-top:30px">
<tr>
<td>Sikeres kilépés</td>
</tr>
</table>